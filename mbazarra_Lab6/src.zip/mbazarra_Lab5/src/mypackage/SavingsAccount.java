package mypackage;

public class SavingsAccount extends BankAccount {
    private static double rate = 0.025; 
    private int savingsNumber = 0;
    private String accountNumber;
    
    public SavingsAccount(String name, double iBalance){
    	super(name, iBalance);
    	this.accountNumber = super.getAccountNumber()+"-"+savingsNumber;
    }
    
    public void postInterest() {
        double interest = getBalance() * rate / 12; 
        deposit(interest); 
    }
    
    @Override
    public String getAccountNumber() {
    	return accountNumber;
    }
    
    public SavingsAccount(SavingsAccount bName, double iBalance){
    	super(bName, iBalance);
    	this.savingsNumber = bName.savingsNumber + 1; 
    	this.accountNumber = super.getAccountNumber() + "-" + savingsNumber;
    }
    
}
