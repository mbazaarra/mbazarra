package mypackage;

public class CheckingAccount extends BankAccount {
	private static final double FEE = 0.15;
	public CheckingAccount(String name, double iAmount){
		super(name, iAmount);
		setAccountNumber(getAccountNumber() + "-10") ;
	}
	
	@Override 
	public boolean withdraw(double amount){
		double tAmount = amount + FEE;
        boolean withdrawalStatus = super.withdraw(tAmount);
        return withdrawalStatus;
	}

}
